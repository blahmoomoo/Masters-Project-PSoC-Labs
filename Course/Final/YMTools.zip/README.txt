YMTools.zip Table of Contents:

Converted/ - YM files that have been converted to be used on the SD card
DecompressedYM/ - decompressed YM files that can be played with Ay_Emul.exe
AY-3-8910.pdf - technical manual for the AY-3-8910
Ay_Emul.exe - emulator for playing back YM files. Can also play back decompressed YM files
lha.exe - LHA decompression program. Use the command line "lha -x <filename>" to decompress <filename>
ym2149.pdf - technical manual for the YM2149. Same functionality as the AY-3-8910 with a few modifications
ymdump.exe - converts decompressed YM files (that don't end in .bin) to the format required for the project

All of these are useful documents, music files, and tools for the YM2149 programmable sound generator
emulator implemented on the PSoC 5LP Development Kit.  Only the music files in Converted are necessary
to run the implementation, but the rest allows for additional music to be used and additional research.

Note that SYNER6/SYNER6.txt make use of at least one special technique that is not implemented in the
emulator on the PSoC. Therefore, it will sound different from how it sounds on the emulator.

Additionally, HITME.YM/HITME.txt makes heavy use of the volume envelope. While this is implemented on the
PSoC, apparently the way the volume envelope works on the emulator is different than what is specified in
the technical manuals, so one of the voices will sound different.